package com.ming.starter;

public class StartService {

    private String hello;

    public StartService(String hello){
        this.hello = hello;
    }

    public String hello(){
        System.out.println(hello);
        return hello;
    }
}
