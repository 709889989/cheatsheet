# nodejs-es6-demo
just demo how to create nodejs project support es6
