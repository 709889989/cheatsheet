package org.javaparser.examples.chapter5;

import org.javaparser.examples.chapter4.*;

class Foo {
    Bar bar;
}