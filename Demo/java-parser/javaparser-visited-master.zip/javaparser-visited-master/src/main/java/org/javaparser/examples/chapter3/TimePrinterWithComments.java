package org.javaparser.examples.chapter3;

import java.time.LocalDateTime;

// Orphaned 1
// Attributed 1
public class TimePrinterWithComments {

    // Orphaned 2
    // Attributed 2
    public static void main(String args[]){
        System.out.print(LocalDateTime.now());
    }
    // Orphaned 3
}
