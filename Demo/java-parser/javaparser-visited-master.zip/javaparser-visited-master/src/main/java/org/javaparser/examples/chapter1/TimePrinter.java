package org.javaparser.examples.chapter1;

import java.time.LocalDateTime;

public class TimePrinter {
    
    public static void main(String args[]){
        System.out.print(LocalDateTime.now());
    }

}
