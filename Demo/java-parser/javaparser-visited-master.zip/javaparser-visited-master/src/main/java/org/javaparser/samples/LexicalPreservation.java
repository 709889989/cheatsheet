package org.javaparser.samples;

// Hey, this is a comment

// Another one
public class LexicalPreservation {


}
