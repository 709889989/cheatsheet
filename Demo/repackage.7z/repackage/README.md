## jar包repackaging 技术

使用jarjar 重新打包jar包为新的命名域，防止解决jar包冲突问题。